. ~/.profile
ORA_PERL="${ORACLE_HOME}/perl/bin/perl"
cd ~/scripts/pcm/codes
$ORA_PERL PCM_FileManager_Demo.pl
