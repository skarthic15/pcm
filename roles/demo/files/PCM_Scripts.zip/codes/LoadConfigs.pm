# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# Description: 
#              This Perl Module is used to load configurations from a ini file
#
# Formats:
#              start with #  - Comments
#              start with ;  - Parent Key (Should be same as to be used inside code)
#              start with ;; - Close any Parent Key
#              empty line    - will be ignored
#
# Author     : Karthik Kumar
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

package LoadConfigs;

use Exporter 'import';
@EXPORT_OK = qw($config);

our $config;

open(CONFIG, "config.ini");

while(my $configLine = <CONFIG>){
	$configLine =~ s/[\r\n]*$//;
	next if($configLine =~ /^\#/); # Lines starting with hash symbol will be ignored
	next if($configLine =~ /^\s*$/); # Empty lines will be ignored
	next if($configLine =~ /^\;;/); # Skip, invalid parent key closures if any
	
	if($configLine =~ /^\;(.*)/){
		my $parentKey = $1;
		while($configLine = <CONFIG>){
			chomp $configLine;
			next if($configLine =~ /^\#/); # Lines starting with hash symbol will be ignored
			next if($configLine =~ /^\s*$/); # Empty lines will be ignored
			last if($configLine =~ /^\;;/); # Close parent keys & jump to main keys
			if($configLine =~ /^\;(.*)/){ # Change/override paent key
				$parentKey = $1;
				next;
			}
			
			my ($key, $value) = split(/\s*=\s*/, $configLine);
			$config->{uc($parentKey)}->{uc($key)} = $value;
		}
	}
	else{
		my ($key, $value) = split(/\s*=\s*/, $configLine);
		$config->{uc($key)} = $value;
	}
}

close CONFIG;
