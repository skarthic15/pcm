# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# Version    : 0.1
# Description: 
#                This Perl program runs in Peoplesoft Camli Managers Demo environment (only!) to synchronize 
#              complete file lists present in Development/Test environment to the self File Repository table.
#                Give instructions for operations like, File Migration, SQL Executions, Bounce etc.,
#
# Author     : Karthik Kumar
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

use strict;
use DBI;
use Net::SMTP;
use POSIX;
use Data::Dumper; # Disable this module in live run

# Load local modules
use LoadConfigs qw($config);
use CommonSubroutines;

# Variables available to the complete program scope
our $debug;
our ($timeString, $timeStamp);
my $dbMessages;

## CHECK BLACKOUTS
blackOutCheck();

#our $dbh = connect_db($config->{INSTANCE_NAME}, $config->{USERNAME}, $config->{PASSWORD});
our $dbh = DBI->connect('dbi:Oracle:', undef, undef, {ora_session_mode => 2, RaiseError => 1, AutoCommit => 0}) or send_error_mail();
# Generic date format used allover script, unless requested explicitly. !!BE CAREFUL IF U ARE ABOUT TO CHANGE THIS FORMAT, IT MAY IMPACT IN MANY FURTHER LOGICS!!
$dbh->do("ALTER SESSION SET NLS_DATE_FORMAT='YYYYMMDDHH24MISS'") or update_msg_exit('Error', 'ALTER SESSION failed!');
$dbh->do("ALTER SESSION SET NLS_TIMESTAMP_FORMAT='YYYYMMDDHH24MISS'") or update_msg_exit('Error', 'ALTER SESSION for timestamp format failed!');
our $schema = $config->{SCHEMA};
our $clnt_schma = $config->{CLIENT_SCHEMA};
die "Error: Schema name to refer tables is required in config file with key SCHEMA !\n" unless $schema;

# Load configurations on DB
our $mail_ids; my ($request_timeout, $retention_days);
&loadDbConfigs;

# Get DB lists
my $db1 = $dbh->selectall_hashref("SELECT M_DBNAME, M_DBLINK FROM $schema.PS_M_DB1", 'M_DBNAME') 
	or update_msg_exit('Error', "SELECT on $schema.PS_M_DB1 failed!");

## SYNC CLIENT CATALOGS
&syncClientCatalog;

## ASSIGN FILE MIGRATION REQUESTS
&assignFmSourceRequest;

# ToDo
## SCAN REQUESTS: 		2. OTHER ACTIONS (Bounce / SQL Executions)



# CHECK SOURCE ACTION STATUS
&checkSourceActionStatus;


# ASSIGN TARGET ACTIONS
&assignTargetActions;

# CHECK TARGET ACTION STATUS
&checkTargetActionStatus;


# Config Syncs
&updateClientConfigs;

# Get status updates of Clients
&getStatusUpdatesOfClients;

# CHECK TIMEOUTS & CLOSURES for all completed things
&closeRequests;


&cleanUps;



update_msg_exit('Success', 'Program ran until end.');

# # # # # # # # # # # # # # # # # # # # # THE END OF PROGRAM # # # # # # # # # # # # # # # # # # # # #





# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# # # # # # # # # # # # # # # # # # # #   LOCAL SUBROUTINES   # # # # # # # # # # # # # # # # # # # #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #


sub loadDbConfigs{
	my $obj = $dbh->selectall_arrayref("SELECT M_EMAILID, M_TIMEOUT, M_RETENTION_DAYS FROM $schema.PS_M_MST_CFG_TBL")->[0];
	die "ERROR: Master configurations missing in table $schema.PS_M_MST_CFG_TBL !!\n" unless $obj;
	($mail_ids, $request_timeout, $retention_days) =  @$obj;
	print "DEBUG: DB Configurations loaded: 
		[Notifications mailing list: $mail_ids]
		[Request Time-out          : $request_timeout minutes]
		[Old objects Retention Days: $retention_days days]\n" if $debug;
}


sub cleanUps{
	# Request table cleanups
	my $ids_ref = $dbh->selectall_hashref("SELECT UNIQUE R.M_REQUEST_ID FROM $schema.PS_M_REQ_TBL R, $schema.PS_M_FILE_RQST_TBL D WHERE R.M_REQ_DATE < CURRENT_DATE - $retention_days AND R.M_REQUEST_ID=D.M_REQUEST_ID", 'M_REQUEST_ID')
		or update_msg_exit('Warning', "SELECT ON $schema.PS_M_REQ_TBL+$schema.PS_M_FILE_RQST_TBL failed!");
	my @ids = keys %$ids_ref;
	if(@ids){
		print("Info: These below request id's file level details (only) will be removed, as it's found older than $retention_days days,\n\t[Request IDs: @ids]\n") if($debug);
		my $ids = join(',', @ids);
		my $deleted_rows = $dbh->do("DELETE FROM $schema.PS_M_FILE_RQST_TBL WHERE M_REQUEST_ID IN ($ids)") or update_msg_exit('Warning', "DELETE on $schema.PS_M_FILE_RQST_TBL failed!");
		print "Info: $deleted_rows rows deleted from table $schema.PS_M_FILE_RQST_TBL\n" if($debug and $deleted_rows);
	}
}


sub updateClientConfigs{
	my $config_ref = $dbh->selectall_hashref("SELECT * FROM $schema.PS_M_CLT_CFG_TBL", 'M_INSTANCE_NAME')
	or update_msg_exit('Error', "SELECT on $schema.PS_M_CLT_CFG_TBL failed!");
	
	foreach my $dbname (keys %$config_ref){
		next if($dbname =~ /^P/i); # if any instance starts with 'P', then dont process those targets
		my $dblink = $db1->{$dbname}->{M_DBLINK};
		my $configs = $config_ref->{$dbname};
		my $lastUpdateDtTm = $dbh->selectall_arrayref("SELECT M_LASTUPDDTTM FROM $clnt_schma.PS_M_CLT_CFG_TBL\@$dblink WHERE M_INSTANCE_NAME='$dbname'") 
			or update_msg_exit('Error', "SELECT on PS_M_CLT_CFG_TBL\@$dblink failed!");
		if($lastUpdateDtTm->[0]->[0]){ # Configuration is present, check LastUpdateDtTm & update if recent
			$lastUpdateDtTm = $lastUpdateDtTm->[0]->[0];
			if($lastUpdateDtTm < $configs->{M_LASTUPDDTTM}){
				$dbh->do("UPDATE $clnt_schma.PS_M_CLT_CFG_TBL\@$dblink
				SET
					M_UNX_SYNC_PATH='$configs->{M_UNX_SYNC_PATH}',
					M_WIN_SYNC_PATH='$configs->{M_WIN_SYNC_PATH}',
					M_FILE_EXTN_SYNC='$configs->{M_FILE_EXTN_SYNC}',
					M_BACKUP_FLAG='$configs->{M_BACKUP_FLAG}',
					M_BKP_LOC_UNX='$configs->{M_BKP_LOC_UNX}',
					M_BKP_LOC_WIN='$configs->{M_BKP_LOC_WIN}',
					M_RETENTION_DAYS=$configs->{M_RETENTION_DAYS},
					M_EMAILID='$configs->{M_EMAILID}',
					M_CLNT_SNC_TIMEOUT=$configs->{M_CLNT_SNC_TIMEOUT},
					M_TIMEOUT=$configs->{M_TIMEOUT},
					M_LASTUPDDTTM=TO_DATE($configs->{M_LASTUPDDTTM}, 'YYYYMMDDHH24MISS'),
					M_BACKUP_LOCATION=' ',
					M_RETENTION_WIN=$configs->{M_RETENTION_WIN},
					M_ADD_CLNP_LOC='$configs->{M_ADD_CLNP_LOC}',
					M_HEARTBEAT=$configs->{M_HEARTBEAT}
				WHERE M_INSTANCE_NAME='$dbname'")
				or update_msg_exit('Error', "UPDATE on PS_M_CLT_CFG_TBL\@$dblink failed!");
			}
		}
		else{ # Configuration not found on client, may be first time, create config entry
			$dbh->do("INSERT INTO $clnt_schma.PS_M_CLT_CFG_TBL\@$dblink 
				(M_INSTANCE_NAME, M_UNX_SYNC_PATH, M_WIN_SYNC_PATH, M_FILE_EXTN_SYNC, M_BACKUP_FLAG, M_BKP_LOC_UNX, M_BKP_LOC_WIN, M_RETENTION_DAYS, M_EMAILID, 
				M_CLNT_SNC_TIMEOUT, M_TIMEOUT, M_LASTUPDDTTM, M_BACKUP_LOCATION, M_RETENTION_WIN, M_ADD_CLNP_LOC, M_HEARTBEAT) VALUES 
				('$dbname', '$configs->{M_UNX_SYNC_PATH}', '$configs->{M_WIN_SYNC_PATH}', '$configs->{M_FILE_EXTN_SYNC}', '$configs->{M_BACKUP_FLAG}',
				'$configs->{M_BKP_LOC_UNX}', '$configs->{M_BKP_LOC_WIN}', $configs->{M_RETENTION_DAYS}, '$configs->{M_EMAILID}', $configs->{M_CLNT_SNC_TIMEOUT}, 
				$configs->{M_TIMEOUT}, TO_DATE($configs->{M_LASTUPDDTTM}, 'YYYYMMDDHH24MISS'), '$configs->{M_BACKUP_LOCATION}', $configs->{M_RETENTION_WIN}, '$configs->{M_ADD_CLNP_LOC}',
				$configs->{M_HEARTBEAT})") or update_msg_exit('Error', "INSERT on PS_M_CLT_CFG_TBL\@$dblink failed!");
		}
	}
}


sub getStatusUpdatesOfClients{
	foreach my $dbname (keys %$db1){ # DB-Name or Instance-Name (considered same)
		my $heartBeatInterval = $dbh->selectall_arrayref("SELECT M_HEARTBEAT FROM $schema.PS_M_CLT_CFG_TBL WHERE M_INSTANCE_NAME='$dbname'") 
			or update_msg_exit('Error', "SELECT on $schema.PS_M_CLT_CFG_TBL failed!");
		$heartBeatInterval = $heartBeatInterval->[0]->[0];
			
		if($dbname !~ /^P/i){ # For non-prod instances
			my $db_link = $db1->{$dbname}->{M_DBLINK};
			my $clntStats = $dbh->selectall_hashref("SELECT * FROM $clnt_schma.PS_M_CLT_STATUS\@$db_link WHERE M_INSTANCE_NAME='$dbname'", 'M_HOST_NAME') or update_msg_exit('Error', "SELECT on PS_M_CLT_STATUS\@$db_link failed!");
				
			foreach my $hostname (keys %$clntStats){
				my $cRef = $clntStats->{$hostname};
				# Mark status on demo side down, if client not updated within configured HeartbeatInterval
				if($heartBeatInterval){
					if(getTimeDiff_min($cRef->{M_LASTUPDDTTM}) > $heartBeatInterval){
						$cRef->{M_STATUS} = 'Down';
						$cRef->{M_COMMENTS} .= "\n[ALL ABOVE LAST COMMENT FROM CLIENT]\n\n\n** MARKING THIS CLIENT AS DOWN, COZ HEARTBEAT NOT FOUND FROM $heartBeatInterval MINUTES **";
					}
				}
				else{
					$cRef->{M_STATUS} = 'Unknown';
					$cRef->{M_COMMENTS} .= "\n[ALL ABOVE LAST COMMENT FROM CLIENT]\n\n\n** MARKING CLIENT STATUS AS UNKNOWN, COZ UNABLE TO FIND HEARTBEAT CONFIG FROM TABLE PS_M_CLT_CFG_TBL **";
				}
				
				# Truncate comments to 254
				if($cRef->{M_COMMENTS} =~ s/^.*(.{240})$/\1/s){
					$cRef->{M_COMMENTS} = "!TRUNCATED!\n" . $cRef->{M_COMMENTS};
				}
				
				# Update client data on demo side
				my $rowsAffected = $dbh->do("UPDATE $schema.PS_M_CLT_STATUS SET M_STATUS='$cRef->{M_STATUS}', M_LASTUPDDTTM=TO_DATE('$cRef->{M_LASTUPDDTTM}', 'yyyymmddhh24miss'),
					M_FULL_SYNC=TO_DATE('$cRef->{M_FULL_SYNC}', 'yyyymmddhh24miss'), M_COMMENTS='$cRef->{M_COMMENTS}' WHERE M_INSTANCE_NAME='$dbname' AND M_HOST_NAME='$hostname'") 
				or update_msg_exit('Error', "UPDATE on $schema.PS_M_CLT_STATUS failed!");
				
				if($rowsAffected > 1){
					update_msg("Warn: 2 entries found & updated in $schema.PS_M_CLT_STATUS for db/host - $dbname/$hostname, this combination shall be only one");
				}
				elsif($rowsAffected eq '0E0'){ # No entries found in demo, but found in client, so, for this db/host, create an entry in demo
					$dbh->do("INSERT INTO $schema.PS_M_CLT_STATUS (M_INSTANCE_NAME, M_HOST_NAME, M_HOST_TYPE, M_STATUS, M_LASTUPDDTTM, M_FULL_SYNC, M_COMMENTS) VALUES 
						('$dbname', '$hostname', '$cRef->{M_HOST_TYPE}', '$cRef->{M_STATUS}', TO_DATE('$cRef->{M_LASTUPDDTTM}', 'yyyymmddhh24miss'), TO_DATE('$cRef->{M_FULL_SYNC}', 'yyyymmddhh24miss'), '$cRef->{M_COMMENTS}')") 
					or update_msg_exit('Error', "INSERT on $schema.PS_M_CLT_STATUS failed!");
				}
			}
		}
		else{ # Prod Instances
			my $clntStats = $dbh->selectall_hashref("SELECT * FROM $schema.PS_M_CLT_STATUS WHERE M_INSTANCE_NAME='$dbname'", 'M_HOST_NAME') or update_msg_exit('Error', "SELECT on $schema.PS_M_CLT_STATUS failed!");
			foreach my $hostname (keys %$clntStats){
				my $cRef = $clntStats->{$hostname};
				# Mark status on demo side down, if client not updated within configured HeartbeatInterval
				if($heartBeatInterval){
					if(getTimeDiff_min($cRef->{M_LASTUPDDTTM}) > $heartBeatInterval){
						$cRef->{M_STATUS} = 'Down';
						$cRef->{M_COMMENTS} .= "\n[ALL ABOVE LAST COMMENT FROM CLIENT]\n\n\n** MARKING THIS CLIENT AS DOWN, COZ HEARTBEAT NOT FOUND FROM $heartBeatInterval MINUTES **";
					}
				}
				else{
					$cRef->{M_STATUS} = 'Unknown';
					$cRef->{M_COMMENTS} .= "\n[ALL ABOVE LAST COMMENT FROM CLIENT]\n\n\n** MARKING CLIENT STATUS AS UNKNOWN, COZ UNABLE TO FIND HEARTBEAT CONFIG FROM TABLE PS_M_CLT_CFG_TBL **";
				}
				
				# Truncate comments to 254
				if($cRef->{M_COMMENTS} =~ s/^.*(.{240})$/\1/s){
					$cRef->{M_COMMENTS} = "!TRUNCATED!\n" . $cRef->{M_COMMENTS};
				}
				
				# Update client data on demo side
				if($cRef->{M_STATUS} =~ /^Down|Unknown$/){
					my $rowsAffected = $dbh->do("UPDATE $schema.PS_M_CLT_STATUS SET M_STATUS='$cRef->{M_STATUS}', M_COMMENTS='$cRef->{M_COMMENTS}' WHERE M_INSTANCE_NAME='$dbname' AND M_HOST_NAME='$hostname'") 
					or update_msg_exit('Error', "UPDATE on $schema.PS_M_CLT_STATUS failed!");
				}
			}
		}
	}
}



sub closeRequests{
	# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
	# Future Implementation # # Handle request closures here for other than File-Migration request types  #
	# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

	
	# All these below code is only for File Migration
	# Logic: Get all Processing ID's from main table, see all those entries in child table, if all completed then complete, if any timeouts, mark it.
	my $completed_ref = $dbh->selectall_hashref("SELECT D.M_REQUEST_ID FROM $schema.PS_M_FILE_RQST_TBL D, $schema.PS_M_REQ_TBL R 
		WHERE R.M_REQUEST_ID=D.M_REQUEST_ID AND D.M_STATUS='Deployment Completed' AND R.M_STATUS='Processing'", 'M_REQUEST_ID')
	or update_msg_exit('Error', "SELECT on $schema.PS_M_FILE_RQST_TBL+$schema.PS_M_REQ_TBL failed!");
	
	my $failed_ref    = $dbh->selectall_hashref("SELECT D.M_REQUEST_ID FROM $schema.PS_M_FILE_RQST_TBL D, $schema.PS_M_REQ_TBL R 
		WHERE R.M_REQUEST_ID=D.M_REQUEST_ID AND D.M_STATUS='Failed' AND R.M_STATUS='Processing'", 'M_REQUEST_ID')
	or update_msg_exit('Error', "SELECT on $schema.PS_M_FILE_RQST_TBL+$schema.PS_M_REQ_TBL failed!");
	
	my $nonFailed_ref = $dbh->selectall_hashref("SELECT D.M_REQUEST_ID FROM $schema.PS_M_FILE_RQST_TBL D, $schema.PS_M_REQ_TBL R
		WHERE R.M_REQUEST_ID=D.M_REQUEST_ID AND D.M_STATUS!='Failed' AND R.M_STATUS='Processing'", 'M_REQUEST_ID')
	or update_msg_exit('Error', "SELECT on $schema.PS_M_FILE_RQST_TBL+$schema.PS_M_REQ_TBL failed!");
	
	my $nonFailedOrCompleted_ref = $dbh->selectall_hashref("SELECT D.M_REQUEST_ID FROM $schema.PS_M_FILE_RQST_TBL D, $schema.PS_M_REQ_TBL R
		WHERE R.M_REQUEST_ID=D.M_REQUEST_ID AND D.M_STATUS NOT IN ('Failed','Deployment Completed') AND R.M_STATUS='Processing'", 'M_REQUEST_ID')
	or update_msg_exit('Error', "SELECT on $schema.PS_M_FILE_RQST_TBL+$schema.PS_M_REQ_TBL failed!");
	
	foreach my $req_id (keys %$completed_ref){
		if(!$failed_ref->{$req_id}){
		# Scenario: All completed
			$dbh->do("UPDATE $schema.PS_M_REQ_TBL SET M_STATUS='Completed' WHERE M_REQUEST_ID='$req_id'") or update_msg_exit('Error', "UPDATE on $schema.PS_M_REQ_TBL failed!");
			$dbh->do("UPDATE $schema.PS_M_FILE_MGR_RQST SET M_MIGRATIONSTATUS='FILE MIGRATION IS COMPLETED' WHERE M_REQUEST_ID='$req_id'") or update_msg_exit('Error', "UPDATE on $schema.PS_M_REQ_TBL failed!");
			print "Info: Req-$req_id Completed\n" if $debug;
		}
		elsif(!$nonFailedOrCompleted_ref->{$req_id}){
		# Scenario: Some completed, & some failed
			$dbh->do("UPDATE $schema.PS_M_REQ_TBL SET M_STATUS='Partially Completed' WHERE M_REQUEST_ID='$req_id'") or update_msg_exit('Error', "UPDATE on $schema.PS_M_REQ_TBL failed!");
			warn "Warn: Req-$req_id Partially completed!\n" if $debug;
		}
		else{
			# still some are in Non Completed/Failed intermediate stage, so dont close this request now itself
			next;
		}
		my $ret_code = &sendFmCompletedMail($req_id, 'Success') if($config->{ENABLE_RFC_EMAIL} =~ /^Y/i);
		warn "Seems completed mail not sent for request-$req_id (Return code: $ret_code)\n" if($ret_code>1);
	}
	
	foreach my $req_id (keys %$failed_ref){
		unless($nonFailed_ref->{$req_id}){
		# Scenario: All failed
			$dbh->do("UPDATE $schema.PS_M_REQ_TBL SET M_STATUS='Failed', M_COMMENTS = M_COMMENTS || '\nAll sub-requests are failed, Check sub request comments for details' WHERE M_REQUEST_ID='$req_id'")
				or update_msg_exit('Error', "UPDATE on $schema.PS_M_REQ_TBL failed!");
			warn "Error: Req-$req_id Failed!\n" if $debug;
			&sendFmCompletedMail($req_id, 'Failed') if($config->{ENABLE_RFC_EMAIL} =~ /^Y/i);
		}
	}
	
	my $processing_reqs = $dbh->selectall_arrayref("SELECT M_REQUEST_ID, M_REQ_DATE FROM $schema.PS_M_REQ_TBL WHERE M_STATUS='Processing'") 
		or update_msg_exit('Error', "SELECT on $schema.PS_M_REQ_TBL failed!");
	
	foreach my $procs_req (@$processing_reqs){
		my ($req_id, $req_time) = @$procs_req;
		if(getTimeDiff_min($req_time) > $request_timeout){
			$dbh->do("UPDATE $schema.PS_M_REQ_TBL SET M_STATUS='Failed', M_COMMENTS = M_COMMENTS || '\nFailed due to Timeout' WHERE M_REQUEST_ID='$req_id'")
				or update_msg_exit('Error', "UPDATE on $schema.PS_M_REQ_TBL failed!");
			warn "Warn: Req-$req_id Timed out!\n" if $debug;
			&sendFmCompletedMail($req_id, 'TimedOut') if($config->{ENABLE_RFC_EMAIL} =~ /^Y/i);
		}
	}
}


sub checkTargetActionStatus{
	my $fmr_ref = $dbh->selectall_arrayref("SELECT M_REQUEST_ID, M_TARGET_DBNAME, M_TARGET_HOSTNAME, M_FILE_NAME, M_LOCATION FROM $schema.PS_M_FILE_RQST_TBL WHERE M_STATUS='Deploying at Target'")
		or update_msg_exit('Error', "SELECT on $schema.PS_M_FILE_RQST_TBL failed!");
		
	foreach my $fmr_row (@$fmr_ref){
		my ($req_id, $t_instance, $t_hostname, $filename, $location) = @$fmr_row;
		next if($t_instance =~ /^P/i);
		my $t_dblink = $db1->{$t_instance}->{M_DBLINK};
		
		my ($status) = $dbh->selectrow_array("SELECT M_STATUS FROM $clnt_schma.PS_M_FILE_CLT_TBL\@$t_dblink 
			WHERE M_REQUEST_ID='$req_id' AND M_TARGET_HOSTNAME='$t_hostname' AND M_LOCATION='$location' AND M_FILE_NAME='$filename'")
			or update_msg_exit('Error', "SELECT on PS_M_FILE_CLT_TBL\@$t_dblink failed!");
		if($status eq 'Completed'){
			# Update Status & file details
			$dbh->do("UPDATE $schema.PS_M_FILE_RQST_TBL SET M_STATUS='Deployment Completed'
				WHERE M_REQUEST_ID='$req_id' AND M_TARGET_DBNAME='$t_instance' AND M_TARGET_HOSTNAME='$t_hostname' AND M_LOCATION='$location' AND M_FILE_NAME='$filename'"
			) or update_msg_exit('Error', "UPDATE on $schema.PS_M_FILE_RQST_TBL failed!");
			print "Info: Deploy completed at $t_hostname, ID-$req_id, $location, $filename\n" if $debug;
		}
		elsif($status =~ /^Failed|Timeout$/){
			$dbh->do("UPDATE $schema.PS_M_FILE_RQST_TBL SET M_STATUS='Failed'
				WHERE M_REQUEST_ID='$req_id' AND M_TARGET_DBNAME='$t_instance' AND M_TARGET_HOSTNAME='$t_hostname' AND M_LOCATION='$location' AND M_FILE_NAME='$filename'"
			) or update_msg_exit('Error', "UPDATE on $schema.PS_M_FILE_RQST_TBL failed!");
			print "Error: Deploy $status for $t_hostname, ID-$req_id, $location, $filename\n" if $debug;
		}
	}
}


sub assignTargetActions{
	# Check if any file still getting from source, if yes then dont assign to target
	my $gettinStill_ref = $dbh->selectall_hashref("SELECT M_REQUEST_ID FROM $schema.PS_M_FILE_RQST_TBL WHERE M_STATUS='Getting from Source'", 'M_REQUEST_ID')
	or update_msg_exit('Error', "SELECT on $schema.PS_M_FILE_RQST_TBL failed!");
	
	# Assign FM target actions
	my $fmr_ref = $dbh->selectall_arrayref("
		SELECT D.M_REQUEST_ID, D.M_TARGET_DBNAME, R.M_REQ_DATE, D.M_SOURCE_HOSTNAME, D.M_TARGET_HOSTNAME, D.M_FILE_NAME, D.M_LOCATION, D.M_MD5, D.M_FILE_SIZE
		FROM $schema.PS_M_REQ_TBL R, $schema.PS_M_FILE_RQST_TBL D
		WHERE R.M_REQUEST_ID=D.M_REQUEST_ID AND R.M_STATUS='Processing' AND R.M_REQ_TYPE='File Migration' AND D.M_STATUS='Received from Source'") 
	or update_msg_exit('Error', "SELECT on $schema.PS_M_REQ_TBL+$schema.PS_M_FILE_RQST_TBL failed!");
		
	foreach my $fmr_row (@$fmr_ref){
		my ($req_id, $t_instance, $req_dt, $s_hostname, $t_hostname, $filename, $location, $md5, $size) = @$fmr_row;
		next if($gettinStill_ref->{$req_id} or $t_instance=~/^P/i);
		print "Info: Deploy Request, ID-$req_id, $t_hostname, $location, $filename\n" if $debug;
		
		# insert client put request
		my $t_dblink = $db1->{$t_instance}->{M_DBLINK};
		$dbh->do("INSERT INTO $clnt_schma.PS_M_FILE_CLT_TBL\@$t_dblink 
			(M_REQUEST_ID, M_SOURCE_HOSTNAME, M_FILE_NAME, M_LOCATION, M_TARGET_HOSTNAME, M_MD5, M_FILE_SIZE, M_STATUS, M_ACTION, M_REQ_DATE, M_COMMENTS)
			VALUES ($req_id, '$s_hostname', '$filename', '$location', '$t_hostname', '$md5', $size, 'Pending', 'Deploy', TO_DATE('$req_dt', 'yyyymmddhh24miss'),' ')") 
		or update_msg_exit('Error', "INSERT on PS_M_FILE_CLT_TBL\@$t_dblink failed!");
		
		print "Info: Updating Files requested in DB. ID-$req_id, $t_hostname, $location, $filename\n" if $debug;
		
		$dbh->do("UPDATE $clnt_schma.PS_M_FILE_CLT_TBL\@$t_dblink 
		SET M_ZIP_FILE=(SELECT M_ZIP_FILE FROM $schema.PS_M_FILE_RQST_TBL 
			WHERE M_REQUEST_ID='$req_id' AND M_TARGET_DBNAME='$t_instance' AND M_TARGET_HOSTNAME='$t_hostname' AND M_LOCATION='$location' AND M_FILE_NAME='$filename')
		WHERE M_REQUEST_ID='$req_id' AND M_TARGET_HOSTNAME='$t_hostname' AND M_LOCATION='$location' AND M_FILE_NAME='$filename'") 
		or update_msg_exit('Error', "UPDATE on PS_M_FILE_CLT_TBL\@$t_dblink failed!");

		# Update Request Status
		$dbh->do("UPDATE $schema.PS_M_FILE_RQST_TBL SET M_STATUS='Deploying at Target' 
			WHERE M_REQUEST_ID='$req_id' AND M_TARGET_DBNAME='$t_instance' AND M_SOURCE_HOSTNAME='$s_hostname' AND M_LOCATION='$location' AND M_FILE_NAME='$filename'"
		) or update_msg_exit('Error', "UPDATE on $schema.PS_M_FILE_RQST_TBL failed!");
	}
	
	# Todo
	# Assign other target actions
}


sub checkSourceActionStatus{
	my $fmr_ref = $dbh->selectall_arrayref("SELECT M_REQUEST_ID, M_SOURCE_DBNAME, M_SOURCE_HOSTNAME, M_FILE_NAME, M_LOCATION FROM $schema.PS_M_FILE_RQST_TBL WHERE M_STATUS='Getting from Source'")
		or update_msg_exit('Error', "SELECT on $schema.PS_M_FILE_RQST_TBL failed!");
		
	foreach my $fmr_row (@$fmr_ref){
		my ($req_id, $s_instance, $s_hostname, $filename, $location) = @$fmr_row;
		next if($s_instance =~ /^P/i); # Skip Prod assignments
		my $source_dblink = $db1->{$s_instance}->{M_DBLINK};
		my $sel_qry = "SELECT M_STATUS, M_MD5, M_FILE_SIZE, M_COMMENTS FROM $clnt_schma.PS_M_FILE_CLT_TBL\@$source_dblink 
			WHERE M_REQUEST_ID='$req_id' AND M_SOURCE_HOSTNAME='$s_hostname' AND M_LOCATION='$location' AND M_FILE_NAME='$filename'";
		my ($status, $md5, $size, $comments) = $dbh->selectrow_array($sel_qry)
			or (warn("\nQUERY EXECUTED:\n$sel_qry\n") and update_msg_exit('Error', "SELECT on PS_M_FILE_CLT_TBL\@$source_dblink failed or no data returned!"));
		if($status eq 'Completed'){
			# Update Status & file details
			$dbh->do("UPDATE $schema.PS_M_FILE_RQST_TBL 
				SET 
					M_FILE_SIZE=$size, M_MD5='$md5', M_STATUS='Received from Source', 
					M_ZIP_FILE=(SELECT M_ZIP_FILE FROM $clnt_schma.PS_M_FILE_CLT_TBL\@$source_dblink 
						WHERE M_REQUEST_ID='$req_id' AND M_SOURCE_HOSTNAME='$s_hostname' AND M_LOCATION='$location' AND M_FILE_NAME='$filename')
				WHERE M_REQUEST_ID='$req_id' AND M_SOURCE_DBNAME='$s_instance' AND M_SOURCE_HOSTNAME='$s_hostname' AND M_LOCATION='$location' AND M_FILE_NAME='$filename'"
			) or update_msg_exit('Error', "UPDATE on $schema.PS_M_FILE_RQST_TBL failed!");
			print "Info: Received file from source, ID-$req_id, $s_hostname, $location, $filename\n" if $debug;
		}
		elsif($status =~ /^Failed|Timeout$/){
			$dbh->do("UPDATE $schema.PS_M_FILE_RQST_TBL SET M_STATUS='Failed', M_COMMENTS='Message from client: $comments'
				WHERE M_REQUEST_ID='$req_id' AND M_SOURCE_DBNAME='$s_instance' AND M_SOURCE_HOSTNAME='$s_hostname' AND M_LOCATION='$location' AND M_FILE_NAME='$filename'"
			) or update_msg_exit('Error', "UPDATE on $schema.PS_M_FILE_RQST_TBL failed!");
			print "Error: Fetch $status for $s_hostname, ID-$req_id, $location, $filename,\tMessage from client: $comments\n" if $debug;
		}
	}
}


sub assignFmSourceRequest{
	my %requests;
	my $fmr_ref = $dbh->selectall_arrayref("
		SELECT DISTINCT D.M_REQUEST_ID, R.M_SOURCE_DBNAME, R.M_REQ_DATE, D.M_SOURCE_HOSTNAME, D.M_FILE_NAME, D.M_LOCATION
		FROM $schema.PS_M_REQ_TBL R, $schema.PS_M_FILE_RQST_TBL D
		WHERE R.M_REQUEST_ID=D.M_REQUEST_ID AND R.M_STATUS='Approved' AND R.M_REQ_TYPE='File Migration' AND D.M_STATUS='File Transfer Requested' AND R.M_SCH_DTTM<CURRENT_DATE
		") or update_msg_exit('Error', "SELECT on $schema.PS_M_REQ_TBL+$schema.PS_M_FILE_RQST_TBL failed!");
	my $counter = 1;
	foreach my $fmr_row (@$fmr_ref){
		my ($req_id, $s_instance, $s_hostname, $filename, $location) = @$fmr_row[0,1,3,4,5];
		next if($s_instance =~ /^P/i); # Skip Prod assignments
		print "Info: Fetch request, ID-$req_id, $s_hostname, $location, $filename\n" if $debug;
		
		$requests{$req_id}{$counter}{M_SOURCE_HOSTNAME} = $s_hostname;
		$requests{$req_id}{$counter}{M_LOCATION} = $location;
		$requests{$req_id}{$counter}{M_FILE_NAME} = $filename;
		$counter++;
		
		# insert client get request
		my $source_dblink = $db1->{$s_instance}->{M_DBLINK};
		$dbh->do("INSERT INTO $clnt_schma.PS_M_FILE_CLT_TBL\@$source_dblink 
			(M_REQUEST_ID, M_SOURCE_HOSTNAME, M_FILE_NAME, M_LOCATION, M_TARGET_HOSTNAME, M_STATUS, M_ACTION, M_REQ_DATE, M_MD5, M_FILE_SIZE, M_COMMENTS) 
			VALUES ($req_id, '$s_hostname', '$filename', '$location', ' ', 'Pending', 'Fetch', TO_DATE('$fmr_row->[2]', 'yyyymmddhh24miss'), ' ', 0, ' ')") 
		or update_msg_exit('Error', "INSERT on PS_M_FILE_CLT_TBL\@$source_dblink failed!");

		# Update Request Status
		$dbh->do("UPDATE $schema.PS_M_FILE_RQST_TBL SET M_STATUS='Getting from Source' 
			WHERE M_REQUEST_ID='$req_id' AND M_SOURCE_DBNAME='$s_instance' AND M_SOURCE_HOSTNAME='$s_hostname' AND M_LOCATION='$location' AND M_FILE_NAME='$filename'"
		) or update_msg_exit('Error', "UPDATE on $schema.PS_M_FILE_RQST_TBL failed!");
	}
	
	foreach my $req_id (keys %requests){
		$dbh->do("UPDATE $schema.PS_M_REQ_TBL SET M_STATUS='Processing' WHERE M_REQUEST_ID='$req_id'") or update_msg_exit('Error', "UPDATE on $schema.PS_M_REQ_TBL failed!");
		$dbh->do("UPDATE $schema.PS_M_FILE_MGR_RQST SET M_STATUS='Processing',M_MIGRATIONSTATUS='Processing'  WHERE M_REQUEST_ID='$req_id'") or update_msg_exit('Error', "UPDATE on $schema.PS_M_REQ_TBL failed!");
	}
}


sub syncClientCatalog{
	foreach my $db_name (keys %$db1){ # DB-Name or Instance-Name (considered same)	
		# if any instance starts with 'P', then dont process those targets
		next if($db_name =~ /^P/i);
		my $db_link = $db1->{$db_name}->{M_DBLINK};
		
		my ($added_counter, $deleted_counter) = (0,0);
		my %demo_data;
		my %target_data;
		
		# Get files list from demo db for comparision with target
		my $demo_query = $dbh->prepare("
			SELECT
				M_FILE_NAME,
				M_LOCATION,
				M_HOST_NAME
			FROM $schema.PS_M_FILE_REPSTORY
			WHERE M_INSTANCE_NAME='$db_name'
		");
		$demo_query->execute or update_msg_exit('Error', "SELECT on $schema.PS_M_FILE_REPSTORY failed!");
		while(my ($file_name, $file_location, $host_name) = $demo_query->fetchrow_array){
			$demo_data{"$file_location/$file_name"} = {
				FILE_NAME => $file_name,
				FILE_LOC  => $file_location,
				HOST_NAME => $host_name
			};
		}
		
		# Get files list from target db via db-link
		my $target_query = $dbh->prepare("
			SELECT
				M_HOST_NAME,
				M_HOST_TYPE,
				M_FILE_TYPE,
				M_FILE_NAME,
				M_LOCATION,
				M_MODIFIED_DATE,
				M_SIZE,
				M_MD5,
				M_SYNCHRONIZED 
			FROM $clnt_schma.PS_M_FILE_REPSTORY\@$db_link
			WHERE M_INSTANCE_NAME='$db_name'
		");
		$target_query->execute or update_msg_exit('Error', "SELECT on PS_M_FILE_REPSTORY\@$db_link failed!");
		
		while(my ($host_name, $host_type, $file_type, $file_name, $file_location, $file_mod_date, $file_size, $file_md5, $sync_flag) = $target_query->fetchrow_array){
			# Sync flag is N, add entry to demo & update target flag as Y
			if($sync_flag eq 'N'){
				$dbh->do("
					DELETE FROM $schema.PS_M_FILE_REPSTORY
					WHERE M_FILE_NAME='$file_name' AND M_LOCATION='$file_location' AND M_INSTANCE_NAME='$db_name' AND M_HOST_NAME='$host_name'
				") or update_msg_exit('Error', "DELETE on $schema.PS_M_FILE_REPSTORY failed!");
				
				my $insert_qry = "INSERT INTO $schema.PS_M_FILE_REPSTORY (M_INSTANCE_NAME, M_HOST_NAME, M_HOST_TYPE, M_FILE_TYPE, M_FILE_NAME, M_LOCATION, M_MODIFIED_DATE, M_SIZE, M_MD5, M_SYNCHRONIZED)
					VALUES ('$db_name', '$host_name', '$host_type', '$file_type', '$file_name',  '$file_location', '$file_mod_date', '$file_size', '$file_md5', '-')";
				my $status = $dbh->do($insert_qry) or update_msg_exit('Error', "INSERT on $schema.PS_M_FILE_REPSTORY failed!");
				print "Fatal: Seems INSERT query has issue, this should update only 1 row, but it has update $status\nSQL QUERY: $insert_qry\n" if($debug and $status!=1);
				
				$dbh->do("
					UPDATE $clnt_schma.PS_M_FILE_REPSTORY\@$db_link
					SET M_SYNCHRONIZED='Y'
					WHERE M_FILE_NAME='$file_name' AND M_LOCATION='$file_location' AND M_INSTANCE_NAME='$db_name' AND M_HOST_NAME='$host_name'
				") or update_msg_exit('Error', "UPDATE on PS_M_FILE_REPSTORY\@$db_link failed!");
				
				# Current updates remove from hash
				delete $demo_data{"$file_location/$file_name"};
				
				$added_counter++;
			}
			else{ # Add already Synchronised entries
				$target_data{"$file_location/$file_name"} = 1;
			}
		}
		
		print("INFO: No. of file details added to Demo from instance '$db_name': $added_counter\n") if($debug);
		
		# remove both sides already syncronized entries
		foreach my $file (keys %target_data){
			delete $demo_data{$file};
		}
		
		# if still something is remained in demo_data hash, means those are not present in target, so delete those entries
		foreach my $file (keys %demo_data){
			my $delete_qry = "DELETE FROM $schema.PS_M_FILE_REPSTORY WHERE 
				M_FILE_NAME='$demo_data{$file}{FILE_NAME}' AND M_LOCATION='$demo_data{$file}{FILE_LOC}' AND M_HOST_NAME='$demo_data{$file}{HOST_NAME}' AND M_INSTANCE_NAME='$db_name' ";
			my $status = $dbh->do($delete_qry) or update_msg_exit('Error', "DELETE on $schema.PS_M_FILE_REPSTORY failed!");
			print "Fatal: Seems DELETE query has issue, this should delete only 1 row, but it has deleted $status\nSQL QUERY: $delete_qry\n" if($debug and $status!=1);
			$deleted_counter++;
		}
		print("INFO: No. of file details deleted from Demo: $deleted_counter\n") if($debug);	
	}
}

# Appends db messages
sub update_msg{
	$dbMessages .= shift() . "\n";
	print $dbMessages if $debug;
}


# Terminates/Stops program & before update necessary status & messages in to database
sub update_msg_exit{
	my $status  = shift;
	my $message = shift;

	my $ret_code = $dbh->do("UPDATE $schema.PS_M_MST_STATUS SET M_LASTUPDDTTM=CURRENT_DATE, M_COMMENTS='$dbMessages\n$timeString - $status: $message'") 
		or warn("Warning: UPDATE on $schema.PS_M_MST_STATUS failed!\n");
	if($ret_code eq '0E0'){ # For first time, if no status row present, then insert one
		$dbh->do("INSERT INTO $schema.PS_M_MST_STATUS (M_LASTUPDDTTM, M_COMMENTS) VALUES (CURRENT_DATE, '$dbMessages\n$timeString - $status: $message')")
		or warn("Warning: INSERT on $schema.PS_M_MST_STATUS failed!\n");
	}
	print "$status: $message\n" if $debug;
	# closures
	$dbh->commit;
	$dbh->disconnect;
	exit;
}
