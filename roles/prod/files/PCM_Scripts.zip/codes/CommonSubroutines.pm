# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# Description: 
#              This Perl Module contains all commonly used subroutines across different programs.
#              this is just module, but not package, so all functionality here will be available at same 
#              package as from which functionality is called.
#
# Author     : Karthik Kumar
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

$0 =~ /^(.*)\...$/;
my $scriptName = join('-', map(ucfirst, split('_', $1)));
my $now = time();
our $debug = $config->{DEBUG_MODE};
our $mail_ids = $config->{EMAIL_TO}; # Initially before db connection, emails from config will be taken, after db loaded, values from db-configs will be overridden in main script
our ($host_type, $host_name) = getHostDetails(); print "Host identified as: $host_type, $host_name\n" if $debug;
our $timeString = strftime "%Y/%b/%d %H:%M %Z", localtime;
our $timeStamp = strftime "%Y%m%d%H%M%S", localtime;
our $dbh; # db connection handler, will be opened in main script
our $schema;

my $smtp_host;
if($host_type eq 'Linux'){
	$smtp_host='localhost';
}
elsif($host_type eq 'Windows'){
	my %smtpHosts=(
		ADC=>'auohs-smtp.oracle.com',
		RMDC=>'rdcsmtp.atoracle.com',
		SLDC=>'sldcsmtp.atoracle.com',
		LLG=>'llgsmtp.atoracle.com',
		TVP=>'tvpsmtp.atoracle.com',
		SYDC=>'sydcsmtp.atoracle.com',
		EPDC=>'epdcsmtp.atoracle.com',
		ADCFOD=>'adcsmtp.fodatoracle.com',
		RMDCFOD=>'rmdcsmtp.fodatoracle.com',
	);
	
	# my $AD_server = $ENV{LOGONSERVER}; $AD_server =~ s/^..//; # This logic works only if logged in with AD user
	
	my $host_short_name = `hostname`; # Below nslookup command throughs message to STDERR as ""Non-authoritative answer:"", this shall be ignored
	my $AD_server = `nslookup $host_short_name`; $AD_server =~ /^Server:\s*(.*)/; $AD_server = $1;

	foreach my $key ($AD_server=~/^(((((.{3}).).).).)/){ # Check's sequentialy from 7 characters until 3 characters
		$key = uc $key;
		if($smtpHosts{$key}){
			$smtp_host = $smtpHosts{$key};
			last;
		}
	}
}



sub blackOutCheck{
	if($host_type eq 'Linux'){
		my $blackOutResult = `/usr/local/cit/bin/em-blackout-cmd -o list`;
		die("Warning: System found as blacked-out, no operations will be done.\n") if($blackOutResult =~ /Targets.*\:host\,/i);
	}
	elsif($host_type eq 'Windows'){
# my $em_service_agent_name = `sc query | findstr /I oracleagent | findstr SERVICE_NAME`;
# $em_service_agent_name =~ s/SERVICE_NAME\:\s*(.*)[\n\s]*/\1/;
# unless($em_service_agent_name){
	# print "Info: Unable to resolve EM Agent service name by code, trying to get from config file\n" if $debug;
	# if($config->{EM_SERVICE_NAME}){
		# $em_service_agent_name = $config->{EM_SERVICE_NAME};;
	# }
	# else{
		# die "Unable to complete blackout check, coz EM Agent service name not able to resolve by code & not available on config file also\n";
	# }
# }
# my $em_agent_path = `REG QUERY HKLM\\Software\\Oracle\\SYSMAN\\$em_service_agent_name /v ORACLE_HOME`;
# $em_agent_path =~ s/^\n*.+\n.+\s+(.+)\n*/\1/;

# my $blackOutResult = `$em_agent_path\\bin\\emctl.bat status blackout`;
# update_msg_exit('Blackout', 'Waning: System found as blacked-out, no operations will be done.') if($blackOutResult =~ /Targets.*\:host\,/i);
		open(XML, $config->{BLKOUT_XML_PATH}) or die "Cannot open file: ". $config->{BLKOUT_XML_PATH}. "\n";
		while(<XML>){
			die("Warning: This system is under Blackout, so no further operations will be done on this system.\n") if(/TYPE\=\"host\"/);
		}
		close XML;
	}
}


sub sendFmCompletedMail{
	my ($request_id, $status) = @_;
	unless($smtp_host){
		warn("Error: On Windows system unable to find SMTP host while sending mail, Job completion for request-$request_id mail not sent!\n");
		return;
	}
	
	my $fromAddrs = $config->{EMAIL_FROM};
	my @toAddrs = split(',', $config->{RFC_EMAIL_ADDRESS});
@toAddrs = split(',', $mail_ids); # temporary overridden values, this line shall be removed after testing
	my $smtp = Net::SMTP->new(Host=>$smtp_host, Port=>25, Timeout=>5, Debug=>0) or die("Error: Mail Sending failed, may be SMTP host not valid, try telnet to smtp_host!\n$!");
	$smtp->mail($fromAddrs);
	if($smtp->to(@toAddrs)){
		$smtp->data(); # start the mail
		$smtp->datasend("To: $_\n") foreach(@toAddrs);
		$smtp->datasend("From: $fromAddrs\n");

		my ($CustSuptId) = $dbh->selectrow_array("SELECT M_CUST_SUPT_ID FROM $schema.PS_M_DB1") or return(2);
		my ($s_dbname, $t_dbname, $req_date, $req_OPR_id, $apprv_OPR_id, $apprv_date, $sys_time, $timezone, $req_status) = $dbh->selectrow_array("
			SELECT M_SOURCE_DBNAME, M_TARGET_DBNAME, TO_CHAR(M_REQ_DATE, 'dd-Mon-yyyy hh24:mi'), M_REQ_OPRID, M_APPRV_ID, TO_CHAR(M_APPRV_DATE, 'dd-Mon-yyyy hh24:mi'), TO_CHAR(SYSTIMESTAMP, 'dd-Mon-yyyy hh24:mi'), SESSIONTIMEZONE, M_STATUS
			FROM $schema.PS_M_REQ_TBL WHERE M_REQUEST_ID=$request_id
		") or return(3);
		my $filesDetails = $dbh->selectall_arrayref("SELECT M_TARGET_HOSTNAME, M_LOCATION, M_FILE_NAME, M_STATUS FROM $schema.PS_M_FILE_RQST_TBL WHERE M_REQUEST_ID=$request_id") or return(4);
		my $opr_id_mail    = $dbh->selectrow_array("SELECT EMAILID FROM $schema.PSUSEREMAIL WHERE OPRID='$req_OPR_id'");
		my $apprv_id_mail = $dbh->selectrow_array("SELECT EMAILID FROM $schema.PSUSEREMAIL WHERE OPRID='$apprv_OPR_id'");
		
		my (%files, $details);
		foreach my $row (@$filesDetails){
			my ($t_host, $loc, $file, $status) = @$row;
			push(@{$files{$t_host}{$status}}, "$loc/$file");
		}
		foreach my $t_host (sort keys %files){
			my ($ht) = $dbh->selectrow_array("SELECT M_HOST_TYPE FROM $schema.PS_M_CLT_STATUS WHERE M_HOST_NAME='$t_host'") or return(7);
			$details .= "*** $t_host - $ht ***\n";
			foreach my $status (sort keys %{$files{$t_host}}){
				$details .= "$status -\n\t" . join("\n\t", @{$files{$t_host}{$status}}) . "\n";
			}
			$details .= "\n";
		}
		
		my $intOrExt = ($req_OPR_id =~ /^OOD_ADM|OOD_PSAPPS$/) ? "Internal" : "External";
		
		$smtp->datasend("Subject: PeopleSoftCloudManager/$t_dbname$timeStamp\n");
		$smtp->datasend("\n");		
		
		$req_date   .= " [$timezone]" if $req_date;
		$apprv_date .= " [$timezone]" if $apprv_date;
		
		$smtp->datasend(
"Migration ID# $request_id:$CustSuptId:$t_dbname:$intOrExt:$status

Migration Details:
--------------------- 

Migration ID# $request_id

Migration $req_status

Migration Scheduled Date : $sys_time [$timezone]

Source Instance: $s_dbname 
Target Instance: $t_dbname

Requester OPRID: $req_OPR_id ($opr_id_mail)
Request Date   : $req_date

Approver OPRID : $apprv_OPR_id ($apprv_id_mail)
Approval Date  : $apprv_date

File Details:
$details

"
		);

		$smtp->dataend();
	}
	else{
		warn "Error: ", $smtp->message();
	}
	
	$smtp->quit;
	print "Job completion mail sent for request-$request_id\n" if $debug;
}

sub connect_db{
	my ($instance, $user, $pass) = @_;
	my $dbh = DBI->connect('dbi:Oracle:' . $instance, $user, $pass, {RaiseError => 0, AutoCommit => 0}) or send_db_connection_error_mail($instance, $user);
	return $dbh;
}

sub send_db_connection_error_mail{
	my ($instance, $user) = @_;
	die("Error: On Windows system unable to find SMTP host while sending mail, DB connection failure mail not sent!\n") unless($smtp_host);

	my $fromAddrs = $config->{EMAIL_FROM};
	my @toAddrs = split(',', $mail_ids);
	my $smtp = Net::SMTP->new(Host=>$smtp_host, Port=>25, Timeout=>5, Debug=>0) or die("Error: Mail Sending failed, may be SMTP host not valid, try telnet to smtp_host!\n$!");
	$smtp->mail($fromAddrs);
	if($smtp->to(@toAddrs)){
		$smtp->data(); # start the mail
		$smtp->datasend("To: $_\n") foreach(@toAddrs);
		$smtp->datasend("From: $fromAddrs\n");
		$smtp->datasend("Subject: Bad db connection\n");
		$smtp->datasend("\n");
		$smtp->datasend("Error: Connection to database <$instance>, user <$user> not possible by scheduler $scriptName.\n");
		$smtp->datasend("Time: $timeString\n");
		$smtp->dataend();
	}
	else{
		warn "Error: ", $smtp->message();
	}
	
	$smtp->quit;
	die("Database connection issue informed to configured mails!\n");
}

# input date should be in format YYYYMMDDHHMMSS
# only one argument
# returns respective perl time in integer (this time will one increment in integer per second wise)
sub getTime{
	my $dt_tm = shift;
	die "Error using function getTime, input date should be in format YYYYMMDDHHMMSS! Data is [$dt_tm]" unless($dt_tm =~ /^\d{14}$/);
	my ($yr, $mon, $dt, $hr, $min, $sec) = $dt_tm =~ /^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/;
	return mktime($sec, $min, $hr, $dt, $mon-1, $yr-1900);
}

# first input shall be older one & second shall be recent ones
# input shall be two dates in format YYYYMMDDHHMMSS
# if second date ignored, then current time will be considered for difference
# Returns time gap in minutes
sub getTimeDiff_min{
	my ($dt1, $dt2) = @_;
	$dt1 = getTime($dt1);
	if($dt2){
		$dt2 = getTime($dt2);
	}
	else{
		$dt2 = $now;
	}
	return int(($dt2-$dt1)/60);
}

# first input shall be older one & second shall be recent ones
# input shall be two dates in format YYYYMMDDHHMMSS
# if second date ignored, then current time will be considered for difference
# Returns time gap in days
sub getTimeDiff_day{
	return int((getTimeDiff_min(@_))/(60*24));
}

sub getHostDetails{
	my ($ht, $hn);
	# Below reg-ex shall be updated based on new scenarios in live runs
	if($^O =~ /linux/i){
		$ht = 'Linux';
		$hn = `hostname -f`; chomp($hn);
	}
	elsif($^O =~ /win/i){
		$ht = 'Windows';
		my $ipconfig = `ipconfig /all`;
		$ipconfig =~ /Host Name[ \.\:]*(.*)/; $hn = $1;
		$ipconfig =~ /Primary Dns Suffix[ \.\:]*(.*)/; $hn .= ".$1";
	}
	return ($ht, $hn);
}

1;