# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# Version    : 0.1
# Description: 
#                This Perl program runs in Peoplesoft Camli Managers Development/Test environment to 
#              update the file lists present in it's self environment to the File Repository table
#                And also it will do some of the other operations like SQL execution, Bounce etc.,
#
# Author     : Karthik Kumar
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

use strict;
use DBI;
use Digest::MD5;
use Net::SMTP;
use POSIX;
use File::Copy;
use File::Path;
use Data::Dumper; # Disable this module in live run

# Load local modules
use LoadConfigs qw($config);
use CommonSubroutines;

# Variables available to the complete program scope
our $debug;
our ($timeString, $timeStamp);
our ($host_type, $host_name);
my $temp_zipfile_name = '.file_from_source.zip';
my $dbMessages;

## CHECK BLACKOUTS
blackOutCheck();

# Connect to database configured
our $dbh = connect_db($config->{INSTANCE_NAME}, $config->{USERNAME}, $config->{PASSWORD});
# Generic date format used allover script, unless requested explicitly. !! **WARNING** - DONOT CHANGE THIS DATE FORMAT, IT WILL IMPACT IN FURTHER LOGICS!!
$dbh->do("ALTER SESSION SET NLS_DATE_FORMAT='YYYYMMDDHH24MISS'") or update_msg_exit('Error', 'ALTER SESSION for date format failed!');
$dbh->do("ALTER SESSION SET NLS_TIMESTAMP_FORMAT='YYYYMMDDHH24MISS'") or update_msg_exit('Error', 'ALTER SESSION for timestamp format failed!');
our $schema = $config->{SCHEMA};
if($config->{SCHEMA}){
	$dbh->do('ALTER SESSION SET CURRENT_SCHEMA=' . $config->{SCHEMA}) or update_msg_exit('Error', 'ALTER SESSION for current_schema failed!');
	print "Default schema changed to: " . $config->{SCHEMA} . "\n" if $debug;
}

# Load client configurations on DB / client shall have only one entry / same table one demo will be having all entries w.r.t instance-name / this will be synced on clients by demo
our $mail_ids;
my ($filePaths, $fileExtensions, $bkp_flag, $bkp_location, $retention_days, $clientSyncTimeout, $req_timeout, $win_retention_days, $cmnBkpForWin, $cleanup_othr_locs);
&loadDbConfigs;

# Read paths
my %env_paths; #hash structure examples#	PS_HOME => ["$ENV{PS_HOME}/sqr", "PS_HOME/sqr"], PS_CUST_HOME => ["$ENV{PS_CUST_HOME}/sqr", "PS_CUST_HOME/sqr"], ... .. .
&read_environment_configured_paths;

# Read file extensions & format it the glob search pattern string. Ex: "*.sqr *.sqc"
my $glob_extensions = '*.' . join(' *.', split(',', $fileExtensions));

## DEPOY NEW FILES
&processDeployRequests;

## SCAN FILE MIGRATION FETCH REQUESTS
&processFetchRequests;


## SYNC FILE CATALOGS
&syncCatalogs;

## PERFORM OTHER ACTION:	1. BOUNCE	2. SQL EXECUTION


## TIMEOUTS
&timeouts;

## CLEANUP OLD LOGS/BACKUPS, also updates win->lin common backup location
&cleanUps; # Not yet tested !!!!!

## UPDATE HEARTBEAT & COMMIT ALL CHANGES DONE
update_msg_exit('Healthy', 'Success: Program ran until end.');

# # # # # # # # # # # # # # # # # # # # # THE END OF PROGRAM # # # # # # # # # # # # # # # # # # # # #






# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# # # # # # # # # # # # # # # # # # # #   LOCAL SUBROUTINES   # # # # # # # # # # # # # # # # # # # #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #


sub read_environment_configured_paths{
	print "DEBUG: Reading Environment values:\n" if $debug;
	foreach(split(',', $filePaths)){
		/^([^\\\/]+)(.*)$/; # $1 will get first string environment variable, & $2 will get remaining part of the directory path
		my ($env, $remaining_path, $env_string_path) = ($1, $2, $_);
		
		# Check environment variables & paths
		unless($ENV{$env}){
			update_msg("Warn: Unable to find environment variable <$env>, configured path $env_string_path will be ignored !");
			next;
		}
		
		unless(-d "$ENV{$env}$remaining_path"){
			update_msg("Warn: Unable to find path, $env_string_path <$ENV{$env}$remaining_path>, this configured path will be ignored !");
			next;
		}
		
		$env_paths{$env} = ["$ENV{$env}$remaining_path", $env_string_path];
		printf("\t[%-12s: %s]\n",$env,$ENV{$env}) if $debug;
	}
}

sub loadDbConfigs{
	my ($filePathsUnx, $filePathsWin, $bkpLocationUnx, $bkpLocationWin);
	
	my $configs = $dbh->selectall_arrayref(
		"SELECT M_UNX_SYNC_PATH, M_WIN_SYNC_PATH, M_FILE_EXTN_SYNC, M_BACKUP_FLAG, M_BKP_LOC_UNX, M_BKP_LOC_WIN, M_RETENTION_DAYS, M_EMAILID, 
			M_CLNT_SNC_TIMEOUT, M_TIMEOUT, M_BACKUP_LOCATION, M_RETENTION_WIN, M_ADD_CLNP_LOC FROM $schema.PS_M_CLT_CFG_TBL
		WHERE M_INSTANCE_NAME='$config->{INSTANCE_NAME}'") or update_msg_exit('Warning', 'SELECT on $schema.PS_M_CLT_CFG_TBL failed!');
	
	update_msg_exit('Warning', 'Configurations on DB not found in table $schema.PS_M_CLT_CFG_TBL, Process aborted!') unless($configs->[0]);
	
	($filePathsUnx, $filePathsWin, $fileExtensions, $bkp_flag, $bkpLocationUnx, $bkpLocationWin, $retention_days, $mail_ids, 
		$clientSyncTimeout, $req_timeout, $cmnBkpForWin, $win_retention_days, $cleanup_othr_locs) = @{$configs->[0]};
	
	if($host_type eq 'Linux'){
		$filePaths = $filePathsUnx;
		$bkp_location = $bkpLocationUnx;
		print "DEBUG: DB Configurations loaded: 
		[Paths to search     : $filePaths]
		[Extensions to search: $fileExtensions]
		[Backup Flag         : $bkp_flag]
		[Backup Location     : $bkp_location]
		[Bkp/Logs Retention  : $retention_days days]
		[Notify mailing list : $mail_ids]
		[Sync time-out       : $clientSyncTimeout minutes]
		[Request Timeout     : $req_timeout minutes]
		[Other Cleanup paths : $cleanup_othr_locs]\n" if $debug;
	}
	elsif($host_type eq 'Windows'){
		$filePaths = $filePathsWin;
		$bkp_location = $bkpLocationWin;
		print "DEBUG: DB Configurations loaded: 
		[Paths to search     : $filePaths]
		[Extensions to search: $fileExtensions]
		[Backup Flag         : $bkp_flag]
		[Backup Location     : $bkp_location]
		[Bkp/Logs Retention  : $retention_days days]
		[Notify mailing list : $mail_ids]
		[Sync time-out       : $clientSyncTimeout minutes]
		[Request Timeout     : $req_timeout minutes]
		[Win Backup Move aftr: $win_retention_days days]
		[Win CmnBkp path aftr: $cmnBkpForWin (Linux client will update this path)]
		[Other Cleanup paths : $cleanup_othr_locs]\n" if $debug;
	}
	
	# Peoplesoft code cannot enter null, so it will enter spaces in paths, handle these issues [make empty spaces as null]
	$bkp_location =~ s/^\s*$//;
	$cmnBkpForWin =~ s/^\s*$//;
	$cleanup_othr_locs =~ s/^\s*$//;
}

sub cleanUps{
	if(-d $bkp_location){
		my $fm_bkp_path = "$bkp_location/FM";
		if(-d $fm_bkp_path){
			print "* Cleaning backup files older than $retention_days days in $fm_bkp_path\n" if $debug;
			# _remove_old_dirs($fm_bkp_path);
			
			&updateWinToLinCommonBackupLocationInConfig unless($cmnBkpForWin);
	
			if($host_type eq 'Windows' and $cmnBkpForWin and $win_retention_days =~ /^\d+$/){
				# Mount common backup linux drive, if not mounted already
				my $win_ood_drive = $config->{WIN_OOD_REP_DRIVE} . ':';
				system("mount $win_ood_drive $cmnBkpForWin") unless(-d "$win_ood_drive\\"); # Ex: Z:\ or X:\
				unless(-d "$win_ood_drive\\"){
					warn "Warning: Seems network drive $win_ood_drive\\ not available & auto mapping might also been failed, so Win->Lin backup moves ignored!\n";
					return;
				}
				
				&windowsBackupMovesToLinux($fm_bkp_path, "$win_ood_drive\\FM");
			}
		}
		else{
			warn "Warn: $fm_bkp_path is not valid backup path for File-migration files, clean up ignored !\n";
		}
	}
	else{
		warn "Warn: $bkp_location is not valid backup path configured in db!\n";
	}
	
	print "* Cleaning files older than $retention_days days in Additional paths configured $cleanup_othr_locs\n" if $debug;
	my @cleanup_othr_locs = split(',', $cleanup_othr_locs);
	_remove_old_dirs($_) foreach(@cleanup_othr_locs);
	_remove_old_files($_) foreach(@cleanup_othr_locs);
	
	my $deleted_rows = $dbh->do("DELETE FROM $schema.PS_M_FILE_CLT_TBL WHERE M_REQ_DATE < CURRENT_DATE - $retention_days") or update_msg_exit('Warning', 'DELETE on $schema.PS_M_FILE_CLT_TBL failed!');
	print "Info: $deleted_rows rows deleted from table $schema.PS_M_FILE_CLT_TBL which are older than $retention_days days\n" if($debug and $deleted_rows ne '0E0');
}

sub windowsBackupMovesToLinux{
	my ($win_bkp_path, $cmn_bkp_path) = @_;
	print "* Moving windows backups to common location for directories modified before $win_retention_days days..\n" if $debug;
	return unless (-d $win_bkp_path and -d $cmn_bkp_path);
	# Zip files requested on request-id folder level & transfer to location $cmnBkpForWin for all request folder more days than configured $win_retention_days.
	opendir(my $dh, $win_bkp_path) or update_msg("Warn: issue in opening directory $win_bkp_path !");
	chdir $win_bkp_path;
	foreach my $dir (grep {-d && ($win_retention_days < -M) && /^[^.]/} readdir $dh){
		system("zip -r $dir.zip $dir");
		unless(move("$dir.zip", "$cmn_bkp_path\\")){
			warn "Unable to move $win_bkp_path\\$dir.zip to $cmn_bkp_path, check permissions! Rolling back zip creation..\n";
			unlink "$dir.zip";
		}
		else{
			rmtree($dir);
			print "Info: Removed directory-tree $win_bkp_path\\$dir, prior it's zipped & moved to $cmn_bkp_path as $dir.zip\n" if $debug;
		}
	}
	closedir $dh;

	# In same request folders level, append details of movement to a log file "Details_MovedToLinuxCommonBackupLocation.log"
}

sub updateWinToLinCommonBackupLocationInConfig{
	if($host_type eq 'Linux' and $bkp_flag=~/^Y/i and -d $bkp_location){
		my $bkp_loc_copy = $bkp_location;
		# Update common linux backup location for Windows; to this location backups will be moved after Windows-retention-days configured
		my $ood_repo = `cd /ood_repository/ && df .`;
		$ood_repo =~ s/^.*\n(.*)\n.*\n/\\\\\1/; # takeout only 2nd line
		$bkp_loc_copy =~ s/\/ood_repository//; $ood_repo .= $bkp_loc_copy; # Make clear path using backup location
		$ood_repo =~ s/[\:\/]+/\\/g; # replace all to forward slash
		$dbh->do("UPDATE $schema.PS_M_CLT_CFG_TBL SET M_BACKUP_LOCATION='$ood_repo'") or update_msg_exit('Warning', 'UPDATE on $schema.PS_M_CLT_CFG_TBL failed!'); # in this table only one row will be present
		$cmnBkpForWin = $ood_repo;
	}
}

sub _remove_old_dirs{
	my $searchDir = shift;
	opendir(my $dh, $searchDir) or update_msg("Warn: Backup Cleanup: Directory not found $searchDir !");
	chdir $searchDir;
	foreach my $dir (grep {-d && ($retention_days < -M) && /^[^.]/} readdir $dh){
		rmtree($dir);
		print "Info: Removed directory-tree $dir\n" if $debug;
	}
	closedir $dh;
}

sub _remove_old_files{
	my $searchDir = shift;
	opendir(my $dh, $searchDir) or update_msg("Warn: Backup Cleanup: Directory not found $searchDir !");
	chdir $searchDir;
	foreach my $file (grep {-f && ($retention_days < -M)} readdir $dh){
		unlink $file;
		print "Info: Removed file $file\n" if $debug;
	}
	closedir $dh;
}

sub timeouts{
	my $fmr_ref = $dbh->selectall_arrayref("SELECT M_REQUEST_ID, M_REQ_DATE, M_SOURCE_HOSTNAME, M_TARGET_HOSTNAME, M_LOCATION, M_FILE_NAME FROM $schema.PS_M_FILE_CLT_TBL
		WHERE M_STATUS='Pending' AND ((M_SOURCE_HOSTNAME='$host_name' AND M_ACTION='Fetch') OR (M_TARGET_HOSTNAME='$host_name' AND M_ACTION='Deploy'))")
	or update_msg_exit('Warning', 'SELECT on $schema.PS_M_FILE_CLT_TBL failed!');
	
	foreach my $fmr_row (@$fmr_ref){
		my ($req_id, $req_time, $s_hostname, $t_hostname, $location, $filename) = @$fmr_row;
		if(getTimeDiff_min($req_time) > $req_timeout){
			$dbh->do("UPDATE $schema.PS_M_FILE_CLT_TBL SET M_STATUS='Timeout' 
			WHERE M_REQUEST_ID=$req_id AND M_SOURCE_HOSTNAME='$s_hostname' AND M_TARGET_HOSTNAME='$t_hostname' AND M_LOCATION='$location' AND M_FILE_NAME='$filename'") 
			or update_msg_exit('Warning', 'UPDATE on $schema.PS_M_FILE_CLT_TBL failed!');
		}
	}
}

# Appends db messages
sub update_msg{
	my $msg = shift() . "\n";
	$dbMessages .= $msg;
	print $msg if $debug;
}

# Terminates/Stops program & before update necessary status & messages in to database
sub update_msg_exit{
	my $status  = shift;
	my $message = shift;
	
	print "$status: $message\n" if $debug;
	
	# Update status & comments
	$dbh->do("UPDATE $schema.PS_M_CLT_STATUS SET M_STATUS='$status', M_COMMENTS='$dbMessages\n$timeString - $message', M_LASTUPDDTTM=CURRENT_DATE
		WHERE M_INSTANCE_NAME='$config->{INSTANCE_NAME}' AND M_HOST_NAME='$host_name'")
	|| die("Error: Final updates on $schema.PS_M_CLT_STATUS failed!\n");
	
	# closures
	$dbh->commit;
	$dbh->disconnect;

	exit;
}

# This subroutine scan all files & inserts to file repository table
sub full_update{
	&updateWinToLinCommonBackupLocationInConfig;
	
	my $counter = 0;
	# Delete all Files details in Repository table
	my $status = $dbh->do("
		DELETE FROM $schema.PS_M_FILE_REPSTORY
		WHERE
			M_INSTANCE_NAME='$config->{INSTANCE_NAME}' AND
			M_HOST_TYPE='$host_type' AND
			M_HOST_NAME='$host_name'
	");
	update_msg("Warning: DELETE on $schema.PS_M_FILE_REPSTORY failed!") unless($status);
	print "INFO: All file details removed from repository table.\n" if($debug and $status);

	foreach my $env (keys %env_paths){
		chdir($env_paths{$env}[0]);

		# Get details of each file & insert to File repository table
		foreach my $file (glob("$glob_extensions")){
			insert_file_details($file, $env_paths{$env}[1]);
			$counter++;
		}
	}
	
	# Update full-sync time in status table
	$dbh->do("UPDATE $schema.PS_M_CLT_STATUS SET M_FULL_SYNC=CURRENT_DATE WHERE M_INSTANCE_NAME='$config->{INSTANCE_NAME}' AND M_HOST_NAME='$host_name'") 
		|| update_msg("Warning: UPDATE on $schema.PS_M_CLT_STATUS failed!");
	
	print "INFO: No. file details added to file-repository: $counter\n" if($debug);
	print "Past data deleted & Full update completed.\n" if($debug);
}

# This subroutine inserts an file details to file-repository
sub insert_file_details{
	my ($file_name, $file_path) = @_;

	# Get file handler
	open(my $file_handler, $file_name); binmode($file_handler);
	# Get few file details
	my $file_type = $file_name; $file_type =~ s/^.*\.([^\.]+)$/\U$1/;
	my ($sec,$min,$hour,$mday,$mon,$year) = localtime((stat($file_name))[9]); $year += 1900; $mon++; # modified date&time
	my $file_size = sprintf("%.3f", (stat($file_name))[7]); # in bytes
	my $file_md5 = Digest::MD5->new->addfile($file_handler)->hexdigest;
	close $file_handler;
	
	$dbh->do("
		INSERT INTO $schema.PS_M_FILE_REPSTORY VALUES (
			'$config->{INSTANCE_NAME}',
			'$host_name', 
			'$host_type', 
			'$file_type', 
			'$file_name',
			'$file_path',
			TO_DATE('$year/$mon/$mday $hour:$min:$sec', 'yyyy/mm/dd hh24:mi:ss'),
			$file_size,
			'$file_md5',
			'N')
		")
	|| update_msg("Warning: INSERT to $schema.PS_M_FILE_REPSTORY failed for: $file_path $file_name!");
}

# This subroutine scans only recently modified & updates file-repository by checking md5
sub partial_update{
	my ($checked_counter, $updated_counter, $added_counter) = (0,0,0); # initiate to zero
	
	foreach my $env (keys %env_paths){
		chdir($env_paths{$env}[0]);
		
		foreach my $file (glob("$glob_extensions")){
			if(-M $file < 0.02){ # will check only for files changed within 28.8 minutes [x = minutes/(24x60)], ex: .5 = 12hrs, 1 = 24hrs
				# Get file handler
				open(my $file_handler, $file); binmode($file_handler);
				my $file_md5 = Digest::MD5->new->addfile($file_handler)->hexdigest;
				close $file_handler;
				
				# Check if details already availble in repository
				my $query = $dbh->prepare("
					SELECT M_MD5 FROM $schema.PS_M_FILE_REPSTORY
					WHERE M_LOCATION='$env_paths{$env}[1]' AND M_FILE_NAME='$file'
				");
				$query->execute || update_msg_exit('Warning', 'SELECT on $schema.PS_M_FILE_REPSTORY failed!');
				my @db_md5 = $query->fetchrow_array;
				
				if(@db_md5){
					# Compare md5 with db repository & update only if changes found
					if($file_md5 ne $db_md5[0]){ # multiple entries should not be their so reading only first element
						# Delete that entry & create a new entry
						$dbh->prepare("
								DELETE FROM $schema.PS_M_FILE_REPSTORY
								WHERE M_LOCATION='$env_paths{$env}[1]' AND M_FILE_NAME='$file'
							")->execute || update_msg_exit('Warning', 'DELETE on $schema.PS_M_FILE_REPSTORY failed!');
						
						insert_file_details($file, $env_paths{$env}[1]);
						$updated_counter++;
					}
				}
				else{ # File entry not found, insert new entry
					insert_file_details($file, $env_paths{$env}[1]);
					$added_counter++;
				}
				
				$checked_counter++;
			}
		}
	}
	
	print "INFO: No. of file details checked: $checked_counter\n" if($debug);
	print "INFO: No. of file details updated: $updated_counter\n" if($debug);
	print "INFO: No. of file details added  : $added_counter\n" if($debug);
	print "Partial update (only for last 30 min changes) completed.\n" if($debug);
}

sub processFetchRequests{
	my $fmr_ref = $dbh->selectall_arrayref("SELECT M_REQUEST_ID, M_LOCATION, M_FILE_NAME FROM $schema.PS_M_FILE_CLT_TBL
		WHERE M_STATUS='Pending' AND M_ACTION='Fetch' AND M_SOURCE_HOSTNAME='$host_name'")
		or update_msg_exit('Warning', 'SELECT on $schema.PS_M_FILE_CLT_TBL failed!');
	
	my $request_count = @$fmr_ref;
	print "* Processing Fetch [$request_count] Requests ...\n" if $debug;
	
	foreach my $fmr_row (@$fmr_ref){
		my $fail;
		my ($req_id, $location, $filename) = @$fmr_row;
		my ($env_var, $path) = $location =~ /^([^\\\/]+)(.*)$/; # $1 will get first string environment variable, & $2 will get remaining part of the directory path
		
		if($ENV{$env_var}){
			$path = $ENV{$env_var} . $path;
			if(-d $path){
				my $file = $path . '/' . $filename;
				if(-f $file){
					my ($file_size) = (stat($file))[7];
					
					open(my $file_handler, $file); binmode($file_handler);
					my $file_md5 = Digest::MD5->new->addfile($file_handler)->hexdigest;
					close $file_handler;
					
					# zip file, before putting into db
					chdir $path;
					`zip $temp_zipfile_name $filename`;
					open(my $file_handler, $temp_zipfile_name); binmode($file_handler);
					read($file_handler, my $zip_file_data, (stat($temp_zipfile_name))[7]);
					close $file_handler;
					unlink $temp_zipfile_name;
					
					# Upload file to BLOB field
					my $updt_query = $dbh->prepare("UPDATE $schema.PS_M_FILE_CLT_TBL SET M_STATUS='Completed', M_MD5='$file_md5', M_FILE_SIZE=$file_size, M_ZIP_FILE=:blob
						WHERE M_REQUEST_ID=$req_id AND M_STATUS='Pending' AND M_ACTION='Fetch' AND M_SOURCE_HOSTNAME='$host_name' AND M_LOCATION='$location' AND M_FILE_NAME='$filename'"
					) or update_msg_exit('Warning', 'Prepare statement error!');
					$updt_query->bind_param(":blob", $zip_file_data, {ora_type=>24});
					$updt_query->execute() or update_msg_exit('Warning', 'UPDATE on $schema.PS_M_FILE_CLT_TBL failed!');
					print "Info: File fetched, @$fmr_row\n" if $debug;
				}
				else{
					$fail .= "Error: File $file not available [in Fetch Action], Req-id: $req_id!\n";
				}
			}
			else{
				$fail .= "Error: Directory M_LOCATION $path not available [in Fetch Action], Req-id: $req_id!\n";
			}
		}
		else{
			$fail .= "Error: Environment variable $env_var in M_LOCATION $fmr_row->[1] not valid [in Fetch Action], Req-id: $req_id!\n";
		}
		
		# After placing file, update status as completed or failed
		if($fail){
			print $fail if $debug;
			$dbh->do("UPDATE $schema.PS_M_FILE_CLT_TBL SET M_STATUS='Failed', M_COMMENTS='$fail'
				WHERE M_REQUEST_ID=$req_id AND M_STATUS='Pending' AND M_ACTION='Fetch' AND M_SOURCE_HOSTNAME='$host_name' AND M_LOCATION='$location' AND M_FILE_NAME='$filename'"
			) or update_msg_exit('Warning', 'UPDATE on $schema.PS_M_FILE_CLT_TBL failed!');
		}
	}
}


sub processDeployRequests{
	my $fmr_ref = $dbh->selectall_arrayref("SELECT M_REQUEST_ID, M_LOCATION, M_FILE_NAME, M_MD5, M_FILE_SIZE FROM $schema.PS_M_FILE_CLT_TBL
		WHERE M_STATUS='Pending' AND M_ACTION='Deploy' AND M_TARGET_HOSTNAME='$host_name'")
		or update_msg_exit('Warning', 'SELECT on $schema.PS_M_FILE_CLT_TBL failed!');
	my $request_count = @$fmr_ref;
	print "* Processing Deploy [$request_count] Requests ...\n" if $debug;
	
	foreach my $fmr_row (@$fmr_ref){
		my $fail;
		my ($req_id, $location, $filename, $db_md5, $file_size) = @$fmr_row;
		my ($env_var, $path) = $location =~ /^([^\\\/]+)(.*)$/; # $1 will get first string environment variable, & $2 will get remaining part of the directory path
		
		if($ENV{$env_var}){
			$path = $ENV{$env_var} . $path;
			if(-d $path){
				my $file = $path . '/' . $filename;
				if(-f $file and $bkp_flag=~/^Y/i){ # move file to backup location
					update_msg_exit('Warning', "Configured Backup-Location $bkp_location not valid/accessable!") unless(-d $bkp_location);
					my $bkp_final_path = "$bkp_location/FM/$req_id/$host_name/$location";
					mkpath($bkp_final_path) unless(-d $bkp_final_path);
					my $bkp_file = "$bkp_final_path/$timeStamp-$filename";
					move($file, $bkp_file) or update_msg_exit('Warning', "File-backup failed: $!");
				}
				
				# Place new file
				$dbh->{LongReadLen} = $file_size + 10000; # ~ +10Kb is just buffer, as file size vary after zip
				my $file_query = $dbh->prepare("SELECT M_ZIP_FILE FROM $schema.PS_M_FILE_CLT_TBL 
					WHERE M_STATUS='Pending' AND M_ACTION='Deploy' AND M_TARGET_HOSTNAME='$host_name' AND M_REQUEST_ID=$req_id AND M_LOCATION='$location' AND M_FILE_NAME='$filename'")
				or update_msg_exit('Warning', 'Prepare query failed!');
				$file_query->execute() or update_msg_exit('Warning', 'SELECT on $schema.PS_M_FILE_CLT_TBL failed!');
				my $zip_file_data = $file_query->fetchrow;
				
				chdir $path;
				open(my $file_handler, ">$temp_zipfile_name") or update_msg_exit('Warning', "Creating compressed temp file failed: $!");
				binmode($file_handler);
				print $file_handler $zip_file_data;
				close $file_handler;
				`unzip -o $temp_zipfile_name`; # if backup not enabled then existing file will be overwritten without any prompt/options
				unlink $temp_zipfile_name;
				
				# Check md5 with db entry
				open(my $file_handler, $file); binmode($file_handler);
				my $file_md5 = Digest::MD5->new->addfile($file_handler)->hexdigest;
				close $file_handler;
				$fail .= 'Deploy failed due to md5 mismatch!' if($db_md5 ne $file_md5);
				print "Info: File Deployed, ID-$req_id $location $filename\n" if $debug;
			}
			else{
				$fail .= "Error: Directory M_LOCATION $path not available, Req-id: $req_id!\n";
			}
		}
		else{
			$fail .= "Error: Environment variable $env_var in M_LOCATION '$location' not valid, Req-id: $req_id!\n";
		}
		
		# After placing file, update status as completed or failed
		if($fail){
			print $fail if $debug;
			$dbh->do("UPDATE $schema.PS_M_FILE_CLT_TBL SET M_STATUS='Failed', M_COMMENTS='$fail'
				WHERE M_REQUEST_ID=$req_id AND M_STATUS='Pending' AND M_ACTION='Deploy' AND M_TARGET_HOSTNAME='$host_name' AND M_LOCATION='$location' AND M_FILE_NAME='$filename'"
			) or update_msg_exit('Warning', 'UPDATE on $schema.PS_M_FILE_CLT_TBL failed!');
		}
		else{
			$dbh->do("UPDATE $schema.PS_M_FILE_CLT_TBL SET M_STATUS='Completed'
				WHERE M_REQUEST_ID=$req_id AND M_STATUS='Pending' AND M_ACTION='Deploy' AND M_TARGET_HOSTNAME='$host_name' AND M_LOCATION='$location' AND M_FILE_NAME='$filename'"
			) or update_msg_exit('Warning', 'UPDATE on $schema.PS_M_FILE_CLT_TBL failed!');
		}
	}
}


sub syncCatalogs{
	print "* Synchronising file catalogs ...\n" if $debug;
	# Check for heart beats & decide full or partial scan


	my $heartbeat_ref = $dbh->selectall_arrayref("SELECT M_LASTUPDDTTM, M_FULL_SYNC FROM $schema.PS_M_CLT_STATUS WHERE M_INSTANCE_NAME='$config->{INSTANCE_NAME}' AND M_HOST_NAME='$host_name'")->[0];
        my $check_config_change = $dbh->selectall_arrayref("SELECT 1 FROM $schema.PS_M_CLT_CFG_TBL where M_LASTUPDDTTM <= (SELECT M_LASTUPDDTTM FROM $schema.PS_M_CLT_STATUS WHERE M_INSTANCE_NAME='$config->{INSTANCE_NAME}' AND M_HOST_NAME='$host_name' ) ")->[0];

	#if($heartbeat_ref and $heartbeat_ref->[1] and $check_config_change and $check_config_change->[1] ){ # If heartbeat record & fullsync_time in it found
	if($heartbeat_ref and $heartbeat_ref->[1] ){ # If heartbeat record & fullsync_time in it found
		my ($heartbeat_time, $fullsync_time) = @$heartbeat_ref;
		my $heartbeat_diff_time = getTimeDiff_min($heartbeat_time);
		my $fullsync_diff_time  = getTimeDiff_day($fullsync_time);
		print "DEBUG: Last heart-beat at $heartbeat_diff_time minute/s back.\n" if($debug);
		print "DEBUG: Last full-sync at $fullsync_diff_time day/s back.\n" if($debug);

		# Update file repository (Full-sync, if last full-sync is beyond one day or heartbeat gap is more than configured)
		if( ($heartbeat_diff_time > $clientSyncTimeout || $fullsync_diff_time > 0) and (!$check_config_change || !$check_config_change->[1]) ){ 
			full_update();
		print "DEBUG: Performing FULL catalog sync.\n" if($debug);
		}
		else{
			partial_update();
		print "DEBUG: Performing PARTIAL catalog sync.\n" if($debug);
		}
	}
	else{ # If heartbeat record not found, then creat
		$dbh->do("INSERT INTO $schema.PS_M_CLT_STATUS (M_INSTANCE_NAME, M_HOST_NAME, M_HOST_TYPE, M_STATUS, M_COMMENTS) VALUES ('$config->{INSTANCE_NAME}', '$host_name', '$host_type', 'Running',' ')")
			|| update_msg("Warning: INSERT on $schema.PS_M_CLT_STATUS failed!");
		full_update();
	}
}

