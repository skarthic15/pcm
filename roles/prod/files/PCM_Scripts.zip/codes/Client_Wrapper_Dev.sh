. ~/.profile
ORA_PERL=/oem1/agent12c/odcagent/core/12.1.0.3.0/perl/bin/perl
cd ~/scripts/pcm/codes
$ORA_PERL PCM_FileManager_Client.pl
