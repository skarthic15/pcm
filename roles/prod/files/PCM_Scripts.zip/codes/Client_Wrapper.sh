. ~/.profile
. /usr/local/bin/upgr
ORA_PERL="/u01/app/oracle/product/11.2.0/perl/bin/perl"
cd ~/pcm/codes
$ORA_PERL PCM_FileManager_Client.pl
